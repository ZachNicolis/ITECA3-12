<?php
define(constant_name: 'DB_HOST', value: '127.0.0.1'); // Use IP instead of 'localhost'
define(constant_name: 'DB_USER', value: 'root');
define(constant_name: 'DB_PASS', value: ''); // Empty password for XAMPP default
define(constant_name: 'DB_NAME', value: 'ecommerce_za');
define(constant_name: 'DB_PORT', value: '3307'); // Add this line
?>