<?php echo "Hello South Africa! Site is working!";
