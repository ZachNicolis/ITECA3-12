</div> <!-- Close container div -->

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>About Us</h5>
                    <p>South Africa's premier online marketplace for authentic local products.</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?= SITE_URL ?>/public/terms" class="text-white">Terms & Conditions</a></li>
                        <li><a href="<?= SITE_URL ?>/public/privacy" class="text-white">Privacy Policy</a></li>
                        <li><a href="<?= SITE_URL ?>/public/contact" class="text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Payment Methods</h5>
                    <div class="payment-methods">
                        <img src="<?= SITE_URL ?>/public/assets/images/payfast.png" alt="PayFast" height="30">
                        <img src="<?= SITE_URL ?>/public/assets/images/eft.png" alt="EFT" height="30">
                        <img src="<?= SITE_URL ?>/public/assets/images/credit-cards.png" alt="Credit Cards" height="30">
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="<?= SITE_URL ?>/public/assets/js/main.js"></script>
    
    <!-- Initialize tooltips -->
    <script>
        $(function () {
            $('[data-bs-toggle="tooltip"]').tooltip()
        })
    </script>
</body>
</html>
