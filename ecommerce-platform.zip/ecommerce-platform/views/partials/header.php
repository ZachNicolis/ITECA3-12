<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(SITE_NAME) ?> - <?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'South African Online Store' ?></title>
    
    <!-- Favicon -->
    <link rel="icon" href="<?= SITE_URL ?>/public/assets/images/favicon.ico">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome (for icons) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link href="<?= SITE_URL ?>/public/assets/css/style.css" rel="stylesheet">
    
    <!-- Google Fonts - Ubuntu (South African friendly font) -->
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navigation Bar (SA-themed) -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?= SITE_URL ?>">
                <img src="<?= SITE_URL ?>/public/assets/images/logo.png" alt="SA E-Commerce" height="40">
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= SITE_URL ?>/public/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= SITE_URL ?>/public/products">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= SITE_URL ?>/public/about">About Us</a>
                    </li>
                </ul>
                
                <div class="d-flex">
                    <a href="<?= SITE_URL ?>/public/cart" class="btn btn-outline-light me-2">
                        <i class="fas fa-shopping-cart"></i> Cart
                        <span class="badge bg-danger cart-count">0</span>
                    </a>
                    
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="<?= ADMIN_URL ?>" class="btn btn-primary">
                            <i class="fas fa-user"></i> Account
                        </a>
                    <?php else: ?>
                        <a href="<?= SITE_URL ?>/public/login" class="btn btn-outline-light">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content Container -->
    <div class="container mt-4 mb-5">
        <!-- Error/Success Messages -->
        <?php if(isset($_SESSION['message'])): ?>
            <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show">
                <?= htmlspecialchars($_SESSION['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
